# -*- coding: UTF-8 -*-
"""
@author: hhyo
@license: Apache Licence
@file: query_privileges.py
@time: 2019/03/24
"""
import logging
import datetime
import re
import traceback

import simplejson as json
from django.contrib.auth.decorators import permission_required
from django.db import transaction
from django.db.models import Q
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
from django.urls import reverse
from django_q.tasks import async_task

from common.config import SysConfig
from common.utils.const import WorkflowDict
from common.utils.extend_json_encoder import ExtendJSONEncoder
from sql.engines.inception import InceptionEngine
from sql.models import QueryPrivilegesApply, QueryPrivileges, Instance, ResourceGroup
from sql.models import MachineApply,MachineInfo,MachineGroup2MachineInfo,MachineGroup
from sql.notify import notify_for_audit
from sql.utils.resource_group import user_groups, user_instances
from sql.utils.workflow_audit import Audit
from sql.utils.sql_utils import extract_tables

logger = logging.getLogger('default')

__author__ = 'hhyo'


@permission_required('sql.menu_machine_query_apply', raise_exception=True)
def machine_apply_list(request):
    """
    获取机器申请工单列表
    :param request:
    :return:
    """
    user = request.user
    limit = int(request.POST.get('limit', 0))
    offset = int(request.POST.get('offset', 0))
    limit = offset + limit
    search = request.POST.get('search', '')

    machine_applys = MachineApply.objects.all()
    # 过滤搜索项，支持模糊搜索标题、用户
    if search:
        machine_applys = machine_applys.filter(
            Q(title__icontains=search) | Q(user_display__icontains=search))
    # 管理员可以看到全部数据
    if user.is_superuser:
        machine_applys = machine_applys
    # 拥有审核权限、可以查看组内所有工单
    elif user.has_perm('sql.machine_review'):
        # 先获取用户所在资源组列表
        group_list = user_groups(user)
        group_ids = [group.group_id for group in group_list]
        machine_applys = machine_applys.filter(group_id__in=group_ids)
    # 其他人只能看到自己提交的工单
    else:
        machine_applys = machine_applys.filter(user_name=user.username)

    count = machine_applys.count()
    lists = machine_applys.order_by('-apply_id')[offset:limit].values(
        'apply_id', 'title', 'install_db_type','apply_type','instance','instance_db_name','machine_cpu', 'machine_mem',
        'machine_disk','machine_total','machine_area',
        'user_display', 'status', 'create_time',
        'group_name','remark','instance','instance_db_name','apply_type'
    )
    # QuerySet 序列化
    rows = [row for row in lists]
    result = {"total": count, "rows": rows}
    # 返回查询结果
    return HttpResponse(json.dumps(result, cls=ExtendJSONEncoder, bigint_as_string=True),
                        content_type='application/json')

@permission_required('sql.menu_machine_info_list', raise_exception=True)
def query_machine_info_list(request):
    """
    获取机器信息列表
    :param request:
    :return:
    """
    #user = request.user
    limit = int(request.POST.get('limit', 0))
    offset = int(request.POST.get('offset', 0))
    limit = offset + limit
    search = request.POST.get('search', '')
    group_id = request.POST.get('group_id','')
    machines = MachineInfo.objects.all()
    if group_id:
        machine_group = MachineGroup.objects.filter(group_id=group_id)
        machinegroup2machineinfo = MachineGroup2MachineInfo.objects.filter(machine_group__in=machine_group)
        machines = MachineInfo.objects.filter(machinegroup2machineinfo__in=machinegroup2machineinfo)
    # 过滤搜索项，支持模糊搜索标题、用户
    if search:
        machines = machines.filter(Q(machine_name__icontains=search))
    count = machines.count()
    lists = machines.order_by('-machine_id')[offset:limit].values(
        'machine_id', 'machine_name', 'machine_private_ip', 'machine_cpu', 'machine_mem',
        'machine_disk','machine_disk_type','machine_system','create_time','comment')
    # QuerySet 序列化
    rows = [row for row in lists]
    result = {"total": count, "rows": rows}
    # 返回查询结果
    return HttpResponse(json.dumps(result, cls=ExtendJSONEncoder, bigint_as_string=True),
                        content_type='application/json')



@permission_required('sql.menu_machine_apply', raise_exception=True)
def machine_apply(request):
    """
    申请机器权限
    :param request:
    :return:
    """
    title = request.POST['title']
    group_name = request.POST.get('group_name')
    group_id = ResourceGroup.objects.get(group_name=group_name).group_id
    install_db_type = request.POST['install_db_type']
    machine_cpu = request.POST['machine_cpu']
    machine_mem = request.POST['machine_mem']
    machine_disk = request.POST['machine_disk']
    machine_total = request.POST['machine_total']
    machine_area = request.POST['machine_area']
    instance_name = request.POST["instance_name"]
    instance_db_name = request.POST['instance_db_name']
    apply_type = request.POST['apply_type']
    remark = request.POST['remark']
    if not machine_total:
        machine_total = 0

    # 获取用户信息
    user = request.user
    result = {"status": 0, "msg": "ok", "data": []}
    # 服务端参数校验
#    if not (title and install_db_type and machine_cpu and machine_mem and
#            machine_disk and machine_total and machine_area and remark):
#        result['status'] = 1
#        result['msg'] = '请填写完整'
#        return HttpResponse(json.dumps(result), content_type="application/json")
#
    # 使用事务保持数据一致性
    try:
        with transaction.atomic():
            # 保存申请信息到数据库
            applyinfo = MachineApply(
                title=title,
                group_id=group_id,
                group_name=group_name,
                install_db_type=install_db_type,
                machine_cpu=machine_cpu,
                machine_mem=machine_mem,
                machine_disk=machine_disk,
                machine_area=machine_area,
                remark=remark,
                instance=instance_name,
                apply_type=apply_type,
                instance_db_name=instance_db_name,
                machine_total=int(machine_total),
                audit_auth_groups=Audit.settings(
                    group_id, WorkflowDict.workflow_type['machinereview']),
                user_name=user.username,
                user_display=user.display,
                status=WorkflowDict.workflow_status['audit_wait'],
            )
            applyinfo.save()
            apply_id = applyinfo.apply_id

            # 调用工作流插入审核信息,查询权限申请workflow_type=1
            audit_result = Audit.add(
                WorkflowDict.workflow_type['machinereview'], apply_id)
            if audit_result['status'] == 0:
                # 更新业务表审核状态,判断是否插入权限信息
                _machine_apply_audit_call_back(
                    apply_id, audit_result['data']['workflow_status'])
    except Exception as msg:
        logger.error(traceback.format_exc())
        result['status'] = 1
        result['msg'] = str(msg)
    else:
        result = audit_result
        # 消息通知
        audit_id = Audit.detail_by_workflow_id(workflow_id=apply_id,
                                               workflow_type=WorkflowDict.workflow_type['machinereview']).audit_id
        async_task(notify_for_audit, audit_id=audit_id, timeout=60)
    return HttpResponse(json.dumps(result), content_type='application/json')


@permission_required('sql.menu_queryapplylist', raise_exception=True)
def user_query_priv(request):
    """
    用户的查询权限管理
    :param request:
    :return:
    """
    user = request.user
    user_display = request.POST.get('user_display', 'all')
    limit = int(request.POST.get('limit'))
    offset = int(request.POST.get('offset'))
    limit = offset + limit
    search = request.POST.get('search', '')

    user_query_privs = QueryPrivileges.objects.filter(
        is_deleted=0, valid_date__gte=datetime.datetime.now())
    # 过滤搜索项，支持模糊搜索用户、数据库、表
    if search:
        user_query_privs = user_query_privs.filter(Q(user_display__icontains=search) |
                                                   Q(db_name__icontains=search) |
                                                   Q(table_name__icontains=search))
    # 过滤用户
    if user_display != 'all':
        user_query_privs = user_query_privs.filter(user_display=user_display)
    # 管理员可以看到全部数据
    if user.is_superuser:
        user_query_privs = user_query_privs
    # 拥有管理权限、可以查看组内所有工单
    elif user.has_perm('sql.query_mgtpriv'):
        # 先获取用户所在资源组列表
        group_list = user_groups(user)
        group_ids = [group.group_id for group in group_list]
        user_query_privs = user_query_privs.filter(
            instance__queryprivilegesapply__group_id__in=group_ids)
    # 其他人只能看到自己提交的工单
    else:
        user_query_privs = user_query_privs.filter(user_name=user.username)

    privileges_count = user_query_privs.distinct().count()
    privileges_list = user_query_privs.distinct().order_by('-privilege_id')[offset:limit].values(
        'privilege_id', 'user_display', 'instance__instance_name', 'db_name', 'priv_type',
        'table_name', 'limit_num', 'valid_date'
    )

    # QuerySet 序列化
    rows = [row for row in privileges_list]

    result = {"total": privileges_count, "rows": rows}
    # 返回查询结果
    return HttpResponse(json.dumps(result, cls=ExtendJSONEncoder, bigint_as_string=True),
                        content_type='application/json')


@permission_required('sql.query_mgtpriv', raise_exception=True)
def query_priv_modify(request):
    """
    变更权限信息
    :param request:
    :return:
    """
    privilege_id = request.POST.get('privilege_id')
    type = request.POST.get('type')
    result = {'status': 0, 'msg': 'ok', 'data': []}

    # type=1删除权限,type=2变更权限
    try:
        privilege = QueryPrivileges.objects.get(privilege_id=int(privilege_id))
    except QueryPrivileges.DoesNotExist:
        result['msg'] = '待操作权限不存在'
        result['status'] = 1
        return HttpResponse(json.dumps(result), content_type='application/json')

    if int(type) == 1:
        # 删除权限
        privilege.is_deleted = 1
        privilege.save(update_fields=['is_deleted'])
        return HttpResponse(json.dumps(result), content_type='application/json')
    elif int(type) == 2:
        # 变更权限
        valid_date = request.POST.get('valid_date')
        limit_num = request.POST.get('limit_num')
        privilege.valid_date = valid_date
        privilege.limit_num = limit_num
        privilege.save(update_fields=['valid_date', 'limit_num'])
        return HttpResponse(json.dumps(result), content_type='application/json')


@permission_required('sql.machine_review', raise_exception=True)
def machine_apply_audit(request):
    """
    机器申请审核
    :param request:
    :return:
    """
    # 获取用户信息
    user = request.user
    apply_id = int(request.POST['apply_id'])
    audit_status = int(request.POST['audit_status'])
    audit_remark = request.POST.get('audit_remark')
    machine_remark = request.POST.get('machine_remark')

    if audit_remark is None:
        audit_remark = ''

    if Audit.can_review(request.user, apply_id, 5) is False:
        context = {'errMsg': '你无权操作当前工单！'}
        return render(request, 'error.html', context)

    if machine_remark:
        for machine_line in machine_remark.split('\n'):
            print(machine_line)
            machine_info = machine_line.split(':')
            IP_RGX = r'(10\.\d{1,3}\.\d{1,3}\.\d{1,3})|(172\.((1[6-9])|(2\d)|(3[01]))\.\d{1,3}\.\d{1,3})|(192\.168\.\d{1,3}\.\d{1,3})$'
            ip_re = re.compile(IP_RGX)
            context = None
            if len(machine_info) == 2 and not ip_re.match(machine_info[1]):
                context = {'errMsg': '输入IP格式错误！'}
            else:
                machine_private_ip = machine_info[0]
                try:
                    machine_name = machine_info[1]
                except Exception as e:
                    machine_name = 'Null'
                try:
                    machine_cpu = machine_info[2]
                except Exception as e:
                    machine_cpu = ''
                try:
                    machine_mem = machine_info[3]
                except Exception as e:
                    machine_mem = ''
                try:
                    machine_disk = machine_info[4]
                except Exception as e:
                    machine_disk = ''
                try:
                    machine_disk_type = machine_info[5]
                except Exception as e:
                    machine_disk_type = ''
                try:
                    machine_system = machine_info[6]
                except Exception as e:
                    machine_system = ''
                try:
                    with transaction.atomic():
                        machine = MachineInfo(machine_name=machine_name,
                                     machine_private_ip=machine_private_ip,
                                     machine_cpu=machine_cpu,
                                     machine_mem=machine_mem,
                                     machine_disk=machine_disk,
                                     machine_disk_type=machine_disk_type,
                                     machine_system=machine_system)
                        machine.save()
                except Exception as e:
                    print(str(e))
                    pass
            if context:
                return render(request, 'error.html', context)

    # 使用事务保持数据一致性
    try:
        with transaction.atomic():
            audit_id = Audit.detail_by_workflow_id(workflow_id=apply_id,
                                                   workflow_type=WorkflowDict.workflow_type['machinereview']).audit_id

            # 调用工作流接口审核
            audit_result = Audit.audit(
                audit_id, audit_status, user.username, audit_remark)

            # 按照审核结果更新业务表审核状态
            audit_detail = Audit.detail(audit_id)
            if audit_detail.workflow_type == WorkflowDict.workflow_type['machinereview']:
                # 更新业务表审核状态,插入权限信息
                _machine_apply_audit_call_back(
                    audit_detail.workflow_id, audit_result['data']['workflow_status'])

    except Exception as msg:
        logger.error(traceback.format_exc())
        context = {'errMsg': msg}
        return render(request, 'error.html', context)
    else:
        # 消息通知
        async_task(notify_for_audit, audit_id=audit_id,
                   audit_remark=audit_remark, timeout=60)

    return HttpResponseRedirect(reverse('sql:machineapplydetail', args=(apply_id,)))


def _machine_apply_audit_call_back(apply_id, workflow_status):
    """
    机器申请用于工作流审核回调
    :param apply_id: 申请id
    :param workflow_status: 审核结果
    :return:
    """
    # 更新业务表状态
    apply_info = MachineApply.objects.get(apply_id=apply_id)
    apply_info.status = workflow_status
    apply_info.save()
    # 审核通过插入权限信息，批量插入，减少性能消耗
    if workflow_status == WorkflowDict.workflow_status['audit_success']:
        #机器申请审核通过,这里对机器IP进行写入机器表
        pass
        #apply_queryset = QueryPrivilegesApply.objects.get(apply_id=apply_id)
        #QueryPrivileges.objects.bulk_create(insert_list)
