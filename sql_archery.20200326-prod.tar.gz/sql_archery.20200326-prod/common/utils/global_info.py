# -*- coding: UTF-8 -*-
from sql.utils.workflow_audit import Audit
from sql.models import Config


def global_info(request):
    """存放用户，菜单信息等."""
    user = request.user
    if user and user.is_authenticated:
        # 获取待办数量
        try:
            todo = Audit.todo(user)
        except Exception:
            todo = 0
    else:
        todo = 0

    return {
        'todo': todo,
    }


def replace_url(request):
    user = request.user
    if user and user.is_authenticated:
        try:
            sql_archery_version = Config.objects.filter(
                item="sql_archery_version")[0].value
            zbx_web_url = Config.objects.filter(item="zabbix_web_url")[0].value
            cachecloud_web_url = Config.objects.filter(
                item="cachecloud_web_url")[0].value
        except Exception as e:
            print(str(e))
            sql_archery_version = "v2.1.0"
            zbx_web_url = "-"
            cachecloud_web_url = "-"
    else:
        sql_archery_version = "v2.1.0"
        zbx_web_url = "-"
        cachecloud_web_url = "-"
    return {
            "sql_archery_version": sql_archery_version,
            "zabbix_web_url": zbx_web_url,
            "cachecloud_web_url": cachecloud_web_url
        }
