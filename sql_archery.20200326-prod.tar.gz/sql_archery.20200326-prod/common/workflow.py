import simplejson as json
from django.contrib.auth.models import Group
from django.db.models import Q
from django.http import HttpResponse

from common.utils.const import WorkflowDict
from common.utils.extend_json_encoder import ExtendJSONEncoder
from sql.models import WorkflowAudit, WorkflowLog,SqlWorkflow,Instance
from sql.utils.resource_group import user_groups


# 获取审核列表
def lists(request):
    # 获取用户信息
    user = request.user

    limit = int(request.POST.get('limit'))
    offset = int(request.POST.get('offset'))
    workflow_type = int(request.POST.get('workflow_type'))
    limit = offset + limit
    search = request.POST.get('search', '')

    # 先获取用户所在资源组列表
    group_list = user_groups(user)
    group_ids = [group.group_id for group in group_list]
    # 再获取用户所在权限组列表
    if user.is_superuser:
        auth_group_ids = [group.id for group in Group.objects.all()]
    else:
        auth_group_ids = [group.id for group in Group.objects.filter(user=user)]

    # 只返回所在资源组当前待自己审核的数据
    workflow_audit = WorkflowAudit.objects.filter(
        workflow_title__icontains=search,
        current_status=WorkflowDict.workflow_status['audit_wait'],
        group_id__in=group_ids,
        current_audit__in=auth_group_ids
    )
    # 过滤工单类型
    if workflow_type != 0:
        if workflow_type == 3 or workflow_type == 2 or workflow_type == 4:
            sqlreview_workflow_list = list()
            output_workflow_list = list()
            redis_workflow_list = list()
            workflow_audit = workflow_audit.filter(Q(workflow_type=2) | Q(workflow_type=3))
            redis_instances = [instance.id for instance in Instance.objects.filter(db_type="redis")]
            for audit in workflow_audit:
                id=audit.workflow_id
                workflow = SqlWorkflow.objects.filter(id=id)
                if workflow:
                    if workflow[0].syntax_type == 0 and workflow[0].instance_id not in redis_instances:
                        output_workflow_list.append(workflow[0].id)
                    elif workflow[0].syntax_type == 1 or workflow[0].syntax_type == 2:
                        sqlreview_workflow_list.append(workflow[0].id)
                    elif workflow[0].syntax_type == 0 and workflow[0].instance_id in redis_instances:
                        redis_workflow_list.append(workflow[0].id)
            if workflow_type == 3:
                workflow_audit = workflow_audit.filter(workflow_id__in=output_workflow_list)
            elif workflow_type == 2:
                workflow_audit = workflow_audit.filter(workflow_id__in=sqlreview_workflow_list)
            elif workflow_type == 4:
                workflow_audit = workflow_audit.filter(workflow_id__in=redis_workflow_list)
        else:
            workflow_audit = workflow_audit.filter(workflow_type=workflow_type)
    audit_list_count = workflow_audit.count()
    audit_list = workflow_audit.order_by('-audit_id')[offset:limit].values(
        'audit_id', 'workflow_type',
        'workflow_title', 'create_user_display',
        'create_time', 'current_status',
        'audit_auth_groups',
        'current_audit',
        'group_name')
    # QuerySet 序列化
    rows = [row for row in audit_list]
    result = {"total": audit_list_count, "rows": rows}
    # 返回查询结果
    res = json.dumps(result, cls=ExtendJSONEncoder, bigint_as_string=True)
    if workflow_type == 3:
        res_dict = json.loads(res)
        for row in res_dict["rows"]:
            row["workflow_type"] = 3
        return HttpResponse(json.dumps(res_dict, cls=ExtendJSONEncoder, bigint_as_string=True),
                        content_type='application/json')
    if workflow_type == 4:
        res_dict = json.loads(res)
        for row in res_dict["rows"]:
            row["workflow_type"] = 4
        return HttpResponse(json.dumps(res_dict, cls=ExtendJSONEncoder, bigint_as_string=True),
                        content_type='application/json')
    return HttpResponse(json.dumps(result, cls=ExtendJSONEncoder, bigint_as_string=True),
                        content_type='application/json')


# 获取工单日志
def log(request):
    workflow_id = request.POST.get('workflow_id')
    workflow_type = request.POST.get('workflow_type')
    try:
        audit_id = WorkflowAudit.objects.get(workflow_id=workflow_id, workflow_type=workflow_type).audit_id
        print(audit_id)
        workflow_logs = WorkflowLog.objects.filter(audit_id=audit_id).order_by('-id').values(
            'operation_type_desc',
            'operation_info',
            'operator_display',
            'operation_time')
        count = WorkflowLog.objects.filter(audit_id=audit_id).count()
    except Exception:
        workflow_logs = []
        count = 0

    # QuerySet 序列化
    rows = [row for row in workflow_logs]
    result = {"total": count, "rows": rows}
    # 返回查询结果
    return HttpResponse(json.dumps(result, cls=ExtendJSONEncoder, bigint_as_string=True),
                        content_type='application/json')
