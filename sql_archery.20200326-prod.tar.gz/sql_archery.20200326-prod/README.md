<div align="center">

# <a href="http://archery.yxzq.com" target="_blank" rel="noopener noreferrer">Archery</a> 

[![Build Status](https://travis-ci.org/hhyo/Archery.svg?branch=master)](https://travis-ci.org/hhyo/Archery)
[![Release](https://img.shields.io/static/v1?message=v2.2.0&&label=release&color=green)](http://szgitlab.youxin.com/yxzq_devops/sql_archery/tags/v2.2.0)
[![codecov](https://codecov.io/gh/hhyo/archery/branch/master/graph/badge.svg)](https://codecov.io/gh/hhyo/archery)
[![version](https://img.shields.io/badge/python-3.6.5-blue.svg)](https://www.python.org/downloads/release/python-365/)
[![version](https://img.shields.io/badge/django-2.0-brightgreen.svg)](https://docs.djangoproject.com/zh-hans/2.0/)
[![License](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](http://github.com/hhyo/archery/blob/master/LICENSE)

[文档](https://github.com/hhyo/archery/wiki) | [FAQ](https://github.com/hhyo/archery/wiki/FAQ) | [Releases](https://github.com/hhyo/archery/releases/)

</div>


介绍
============
Archery是[archer](https://github.com/jly8866/archer)的分支项目，定位于SQL审核查询平台，附加部分DB运维功能，所有功能都兼容手机端操作，[功能列表](https://github.com/hhyo/Archery/wiki/功能列表)

当前项目是从Archery v1.6.5开始进行二次开发，运行 ./build.sh 制作运行镜像

