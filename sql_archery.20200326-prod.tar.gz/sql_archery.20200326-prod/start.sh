#!/bin/bash
source /opt/venv4archery/bin/activate 
cd /opt/sql_archery 
tar -zxf /opt/sql_archery/lib.tar.gz -C /opt/ && rm -rf /opt/venv4archery/lib && mv /opt/lib /opt/venv4archery/
python manage.py makemigrations sql 
python manage.py migrate 
supervisord -c qcluster_supervisord.conf 
python manage.py runserver 0.0.0.0:99 --insecure
